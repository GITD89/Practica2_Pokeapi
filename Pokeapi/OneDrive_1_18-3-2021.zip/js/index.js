let _main = document.querySelector('#contenedor') 

_main.addEventListener('click', pokemon);



function pokemon(){
    fetch("http://pokeapi.co/api/v2/pokemon/3")
    .then((resp)=>resp.json())
    .then((res)=>{
        _main.innerHTML=`
            <h2>${res.name}</h2>
            <img src='${res.sprites.front_shiny}' width='300px'></img>
            <div>
                <h3>STATS</h3>
                <div>
                    <span>${res.stats[0].stat.name} : </span>
                    <span>${res.stats[0].base_stat}</span>
                </div>
                
                ${res.stats[1].base_stat}
                ${res.stats[2].base_stat}
                ${res.stats[3].base_stat}
                ${res.stats[4].base_stat}
                ${res.stats[5].base_stat}
            </div>
        `;
        console.log(res);
    })
}
